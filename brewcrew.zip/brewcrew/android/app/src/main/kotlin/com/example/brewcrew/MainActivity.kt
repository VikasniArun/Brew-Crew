package com.example.brewcrew

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
