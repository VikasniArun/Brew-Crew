import 'package:brewcrew/shared/constants.dart';
import 'package:brewcrew/shared/loading.dart';
import 'package:flutter/material.dart';
import '/services/auth.dart';

// AuthService class for authentication operation
// SignIn widget
class SignIn extends StatefulWidget {
  final Function toggleview;
  const SignIn({super.key, required this.toggleview});

  @override
  State<SignIn> createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  final AuthService _auth = AuthService();
  final _formKey = GlobalKey<FormState>();
  bool loading = false;

  //text field state
  String email = '';
  String password = '';
  String error = '';

  @override
  Widget build(BuildContext context) {
    return loading
        ? const Loading()
        : Scaffold(
            backgroundColor: Colors.brown[100],
            appBar: AppBar(
              backgroundColor: Colors.brown[300],
              elevation: 0.0,
              title: const Text('Sign in to Brew Crew'),
              actions: [
                TextButton.icon(
                    onPressed: () {
                      widget.toggleview();
                    },
                    icon: const Icon(
                      Icons.person,
                      color: Colors.black,
                    ),
                    label: const Text(
                      "Register",
                      style: TextStyle(color: Colors.black),
                    ))
              ],
            ),
            body: Container(
                padding: const EdgeInsets.symmetric(
                    vertical: 20.0, horizontal: 50.0),
                child: Form(
                    key: _formKey,
                    child: Column(
                      children: <Widget>[
                        const SizedBox(height: 20.0),
                        TextFormField(
                          decoration:
                              textInputDecoration.copyWith(hintText: 'email'),
                          validator: (val) =>
                              val!.isEmpty ? 'Enter an email' : null,
                          onChanged: (val) {
                            setState(() => email = val);
                          },
                        ),
                        const SizedBox(
                          height: 20.0,
                        ),
                        TextFormField(
                            decoration: textInputDecoration.copyWith(
                                hintText: 'password'),
                            validator: (val) => val!.length < 6
                                ? 'Enter a password 6+ chars long'
                                : null,
                            obscureText: true,
                            onChanged: (val) {
                              setState(() => password = val);
                            }),
                        const SizedBox(
                          height: 20.0,
                        ),
                        TextButton(
                            onPressed: () async {
                              if (_formKey.currentState!.validate()) {
                                setState(() => loading = true);
                                dynamic result =
                                    await _auth.signingInWithEmailAndPassword(
                                        email, password);
                                if (result == null) {
                                  setState(() => loading = false);
                                  setState(() => error =
                                      'could not sign in using those credentials');
                                }
                              }
                            },
                            style: TextButton.styleFrom(
                              foregroundColor: Colors.black,
                              backgroundColor:
                                  Colors.pinkAccent, // Background color
                              padding: const EdgeInsets.all(16.0),
                            ),
                            child: const Text(
                              "Sign in",
                              style: TextStyle(color: Colors.white),
                            )),
                        const SizedBox(
                          height: 12.0,
                        ),
                        Text(
                          error,
                          style: const TextStyle(
                              color: Colors.red, fontSize: 14.0),
                        )
                      ],
                    ))),
          );
  }
}
