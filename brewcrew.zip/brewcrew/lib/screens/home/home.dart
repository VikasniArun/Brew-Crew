import 'package:brewcrew/models/brew.dart';
import 'package:brewcrew/screens/home/settings_form.dart';
import 'package:brewcrew/services/auth.dart';
import 'package:flutter/material.dart';
import '/services/database.dart';
import 'package:provider/provider.dart';
import 'package:brewcrew/screens/home/brew_list.dart';

class Home extends StatelessWidget {
  final AuthService _auth = AuthService();
  Home({super.key});

  @override
  Widget build(BuildContext context) {
    void showSettingsPanel() {
      showModalBottomSheet(
          context: context,
          builder: (context) {
            return Container(
              padding:
                  const EdgeInsets.symmetric(vertical: 40.0, horizontal: 100.0),
              child: const SettingForm(),
            );
          });
    }

    return StreamProvider<List<Brew>>.value(
      value: DatabaseService(uid: '').brews,
      initialData: const [],
      child: Scaffold(
        backgroundColor: Colors.brown[400],
        appBar: AppBar(
          title: const Text(
            "Brew Crew",
          ),
          backgroundColor: Colors.brown[300],
          elevation: 0.0,
          actions: <Widget>[
            TextButton.icon(
              onPressed: () async {
                await _auth.signOut();
              },
              icon: const Icon(
                Icons.person,
                color: Colors.black, // Change icon color to black
              ),
              label: const Text(
                "Logout",
                style: TextStyle(
                    color: Colors.black), // Change text color to black
              ),
            ),
            TextButton.icon(
              onPressed: () => showSettingsPanel(),
              icon: const Icon(
                Icons.settings,
                color: Colors.black, // Change icon color to black
              ),
              label: const Text(
                'Settings',
                style: TextStyle(
                    color: Colors.black), // Change text color to black
              ),
            )
          ],
        ),
        body: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage('coffee_bg.png'),
              fit: BoxFit.cover,
            ),
          ),
          child: const BrewList(),
        ),
      ),
    );
  }
}
